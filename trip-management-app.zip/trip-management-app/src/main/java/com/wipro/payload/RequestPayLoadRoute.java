package com.wipro.payload;

public class RequestPayLoadRoute {
	
}

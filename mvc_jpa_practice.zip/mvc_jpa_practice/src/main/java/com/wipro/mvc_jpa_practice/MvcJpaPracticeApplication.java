package com.wipro.mvc_jpa_practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcJpaPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcJpaPracticeApplication.class, args);
	}

}

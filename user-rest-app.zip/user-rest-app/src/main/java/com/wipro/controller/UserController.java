package com.wipro.controller;

import java.util.List;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.wipro.exception.UserException;
import com.wipro.model.User;
import com.wipro.payload.RequestPayload;
import com.wipro.payload.ResponsePayload;
import com.wipro.service.UserServiceSpringData;

//import lombok.extern.slf4j.Slf4j;

@RestController
//@Slf4j
@RequestMapping("/uc")
public class UserController {
//	private Logger logger = LoggerFactory.getLogger(UserController.class);

//	@Autowired
//	private UserService userService;

	@Autowired
	private UserServiceSpringData userService;
	
	
	//http://localhost:8081/users/1
	@GetMapping("/users/{id}")
	public ResponseEntity<User> getUserById(@PathVariable(name = "id") Integer id) {
		try {
			User user = userService.getUserById(id);
//			logger.info(user.toString());
//			log.info(user.toString());
			return new ResponseEntity<>(user, HttpStatus.OK);
		}catch(UserException e) {
			//			e.printStackTrace();
//			logger.error(e.getMessage(),e);
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
			
		}
		
	}


	//http://localhost:8081/users
	@GetMapping("/users")
	public List<User> getAllUsers() {
		try {
			List<User> userList =  userService.getAllUsers();
//			logger.info("Sending entire user list..");
			return userList;
		}catch(UserException e) {
			//			e.printStackTrace();
//			logger.error(e.getMessage(),e);
		}
		return null;
	}


	@PostMapping("/users")
	public String addUser( @RequestBody User user) {
		try {
			String message=  userService.addUser(user);
//			logger.info(message);
			return message;

		}catch(UserException e) {
			//			e.printStackTrace();
//			logger.error(e.getMessage(),e);
		}
		return null;
	}

	//	@PutMapping("/users")
	//	public User updateUser( @RequestBody User user) {
	//		try {
	//			return userService.updateUSer(user);
	//			
	//		}catch(UserException e) {
	//			e.printStackTrace();
	//		}
	//		return null;
	//	}

	@PutMapping("/users")
	public User updateUser( @RequestBody RequestPayload requestPayload) {
		try {
			User user = userService.updateUser(requestPayload);
//			logger.info(user.toString());
			return user;

		}catch(UserException e) {
			e.printStackTrace();
		}
		return null;
	}

	@DeleteMapping("/users/{id}")
	public String deleteUser( @PathVariable(name = "id") Integer id) {
		try {
			String message =  userService.deleteUser(id);
//			logger.info(message);
			return message;
		}catch(UserException e) {
			e.printStackTrace();
		}
		return "Invalid ID";
	}

	//API END-POINT RETURNS ALL THE USERS USERNAME & EMAIL(List<ResponsePayload>)
	// http://localhost:8081/uc/users/email

	//http://localhost:8081/users
	@GetMapping("/users/email")
	public List<ResponsePayload> getAllUserEmails() {
		try {
			List<ResponsePayload> userEmailList =  userService.getAllUserEmails();
//			logger.info("Sending all usernames annd their emails..");
			return userEmailList;
		}catch(UserException e) {
			//				e.printStackTrace();
//			logger.error(e.getMessage(),e);
		}
		return null;
	}
	
	
//	   @GetMapping("/users/page")
//	    public List<User> getUserWithPaging(@RequestParam(name="pageno",defaultValue = "1") Integer pageNo,
//	                                        @RequestParam(name="pagesize",defaultValue = "1") Integer pageSize){
//
//
//	        return userService.getUsersByPagination(pageNo,pageSize);
//	    }
	
	// http://localhost:8081/users/page?pageno=2&pagesize=2
		@GetMapping("/users/page")
		public List<User> getUserWithPaging(@RequestParam(name = "pageno", defaultValue = "1") Integer pageNo,
				@RequestParam( name = "pagesize", defaultValue = "1") Integer pageSize){
			try {
				return userService.getUsersByPagination(pageNo-1,pageSize);
			}catch(Exception e) {
				//			e.printStackTrace();
			}
			return null;
		}
		// http://localhost:8081/users/sort/username
		@GetMapping("/users/sort/{name}")
		public List<User> getSortedtUsers(@PathVariable(name="name") String name){
			try {
				return userService.getSortedUsers(name);
			}catch(Exception e) {
			}
			return null;
		}


	

}

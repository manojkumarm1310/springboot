package com.wipro.aspect;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
/**
 *  The methods of regular classes are called as JoinPoints.
 *  The below Aspect method  (here action is the code written within
 *  this method) is executed before( @Before advice), the execution of JoinPoint method,
 *  which is getUserById() as per the Pointcut expression.
 */
@Aspect
@Component
//@Slf4j
public class UserAspect {
	private Logger log = LoggerFactory.getLogger(UserAspect.class);
	
//	@Before("execution( * com.wipro.controller.UserController.get*(..))")
//	public void beforeAdvice(JoinPoint joinPoint) {
//		System.out.println("Executing aspect method...");
//		System.out.println("JoinPint method is "+ joinPoint.getSignature().getName());
//	}
	
//	@Around("execution( * com.wipro.controller.UserController.get*(..))")
//	public Object beforeAdvice(ProceedingJoinPoint joinPoint) throws Throwable {
//		System.out.println("Before joinPoint method, "+ joinPoint.getSignature().getName());
//		//explicitly invoke JoinPoint method
//
//		Object object = joinPoint.proceed();
//		
//		
//		System.out.println("After joinPoint method, "+ joinPoint.getSignature().getName());
//		
//		return object;
//	}
	
	
	@Pointcut("execution(* com.wipro.controller.UserController.*(..))")
	public void applicationPackagePointcut() {

	}

	@Around("applicationPackagePointcut()")
	public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {

		try {
			if (log.isDebugEnabled()) {
				log.debug("Entering method : {}.{}() with argument[s] = {}", joinPoint.getSignature().getDeclaringTypeName(),
						joinPoint.getSignature().getName(), Arrays.toString(joinPoint.getArgs()));
			}
			try {
				//explicitly invoke joinpoint method
				Object object = joinPoint.proceed();

				if (log.isDebugEnabled()) {					
					log.debug("Exiting method: {}.{}() with result = {}", joinPoint.getSignature().getDeclaringTypeName(),
							joinPoint.getSignature().getName(), object);
				}
				return object;
			} catch (Exception e) {
				log.error("Error in {}.{}()", joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName());
				log.error(e.getMessage());
				throw e;
			}
		}catch(Exception e) {
			log.error(e.getMessage());
			throw e;
		}
	}
	
	
	@AfterThrowing(pointcut = "execution(* com.wipro.controller.UserController.*(..))", throwing = "e")
	public void logAfterThrowing(JoinPoint joinPoint, Exception e) throws Throwable {

		
				log.error("Error in {}.{}(), {}", joinPoint.getSignature().getDeclaringTypeName(),
						joinPoint.getSignature().getName(),e.getMessage());
	
	}
	
}

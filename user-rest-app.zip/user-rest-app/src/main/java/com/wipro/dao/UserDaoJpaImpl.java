package com.wipro.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.stereotype.Repository;

import com.wipro.model.User;
import com.wipro.payload.RequestPayload;
import com.wipro.payload.ResponsePayload;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

@Repository
public class UserDaoJpaImpl implements UserDAO {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public User getUserById(Integer id) throws DataAccessException {
		try {
			User user = entityManager.find(User.class, id);
			if(user == null) {
				throw new DataRetrievalFailureException("Invalid userID");
			}
			return user;
		}catch(DataAccessException e) {
			throw e;
		}
	}

	@Override
	public List<User> getAllUsers() throws DataAccessException {
		String jql = "select u from User u";
		try {
			TypedQuery<User> tq = entityManager.createQuery(jql, User.class);
			List<User> userList = tq.getResultList();
			if(userList.size()==0) {
				throw new DataRetrievalFailureException("Table is empty");
			}
			return userList;
		}catch(DataAccessException e) {
			throw e;
		}
	}

	@Override
	public String addUser(User user) throws DataAccessException {
		try {
			entityManager.persist(user);
			entityManager.flush();
			return user.getUsername()+" added to database";
			
		}catch(DataAccessException e) {
			throw e;
		}
	}

	@Override
	public User updateUser(RequestPayload requestPayload) throws DataAccessException {
		try {
			User user = this.getUserById(requestPayload.getId());
			user.setPassword(requestPayload.getPassword());
			user.setAddress(requestPayload.getAddress());
			user.setEmail(requestPayload.getEmail());
			user.setMobile(requestPayload.getMobile());
			entityManager.merge(user);
			return user;
			
		}catch(DataAccessException e) {
			throw e;
		}
	}

	@Override
	public String deleteUser(Integer id) throws DataAccessException {
		try {
			User user = this.getUserById(id);			
			entityManager.remove(user);
			entityManager.flush();
			return user.getUsername()+" removed from database";
			
		}catch(DataAccessException e) {
			throw e;
		}
	}

	@Override
	public List<ResponsePayload> getAllUserEmails() throws DataAccessException {
		String jql = "select u from User u";
		try {
			TypedQuery<User> tq = entityManager.createNamedQuery(jql, User.class);
			List<User> userList = tq.getResultList();
			if(userList.size()==0) {
				throw new DataRetrievalFailureException("Table is empty");
			}
			
			List<ResponsePayload> respList = new ArrayList<>();
			Iterator<User> iterator = userList.iterator();
			while(iterator.hasNext()) {
				User tempUser = iterator.next();
				ResponsePayload responsePayload = new ResponsePayload();
				responsePayload.setUsername(tempUser.getUsername());
				responsePayload.setEmail(tempUser.getEmail());
				respList.add(responsePayload);
			}
			
			
			return respList;
		}catch(DataAccessException e) {
			throw e;
		}
	}

}

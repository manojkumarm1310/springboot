package com.wipro.dao;

import java.sql.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.support.TransactionTemplate;

import com.wipro.mapper.UserRowMapper;
import com.wipro.model.User;
import com.wipro.payload.RequestPayload;
import com.wipro.payload.ResponsePayload;

@Repository
public class UserDaoImpl implements UserDAO{
	
	
	private Logger logger = LoggerFactory.getLogger(UserDaoImpl.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private TransactionTemplate transactionTemplate;
	
	@Autowired
	private UserRowMapper userRowMapper;
	
	@Autowired
	private BeanPropertyRowMapper<User> userBeanPropertyRowMapper;
	
	@Autowired
	private BeanPropertyRowMapper<ResponsePayload> responseBeanPropertyRowMapper;

	@Override
	public User getUserById(Integer id) throws DataAccessException {
		String query = "SELECT * FROM USER_24NAG2088 WHERE ID = ?";
		try {
			User user = jdbcTemplate.queryForObject(query, userRowMapper,id);
			return user;
			
		}catch(DataAccessException e) {
			logger.error(e.getMessage());
			throw e;
		}
		
	}

	@Override
	public List<User> getAllUsers() throws DataAccessException {
		String query = "SELECT * FROM USER_24NAG2088";
		try {
//			List<User> userList = jdbcTemplate.query(query, userRowMapper);
			List<User> userList = jdbcTemplate.query(query, userBeanPropertyRowMapper);
			return userList;
			
		}catch(DataAccessException e) {
			throw e;
		}
	}

	@Override
	public String addUser(User user) throws DataAccessException {
		String query = "INSERT INTO USER_24NAG2088 values(?,?,?,?,?,?,?)";
		try {
			
			//convert java.time.LocalDate to java.sql.Date, use Date.valueOf()
			int n = jdbcTemplate.update(query,user.getId(),user.getUsername(), user.getPassword(),
					Date.valueOf(user.getBirthdate()),user.getAddress(),user.getEmail(),user.getMobile() );
			if(n>0) {
				return "User: "+ user.getId()+" added to database";
			}else{
				return "Unable to add user to the database";
			}
		}catch(DataAccessException e) {
			throw e;
		}
	}

//	@Override
//	public User updateUSer(User user) throws DataAccessException {
//		String query = "UPDATE USER_24NAG2088 set password=?,email=?,address=?,mobile=? WHERE ID=?";
//		try {
//			
//			int n = jdbcTemplate.update(query,user.getPassword(),user.getEmail(), 
//					user.getAddress(),user.getMobile(), user.getId() );
//			return user;
//		}catch(DataAccessException e) {
//			throw e;
//		}
//	}

	
	@Override
	public User updateUser(RequestPayload requestPayload) throws DataAccessException {
		String query = "UPDATE USER_24NAG2088 set password=?,email=?,address=?,mobile=? WHERE ID=?";
		try {
			
			int n = jdbcTemplate.update(query,requestPayload.getPassword(),
					requestPayload.getEmail(), 
					requestPayload.getAddress(),requestPayload.getMobile(), 
					requestPayload.getId() );
			
			return this.getUserById(requestPayload.getId());
		}catch(DataAccessException e) {
			throw e;
		}
	}
	
	
	@Override
	public String deleteUser(Integer id) throws DataAccessException {
		String query = "DELETE FROM USER_24NAG2088 WHERE ID=?";
		try {
			
			int n = jdbcTemplate.update(query, id );
			if(n>0) {
				return "UserId:" + id+ " deleted from database";
			}else {
				return "Invalid Id";
			}
		}catch(DataAccessException e) {
			throw e;
		}
	}

	@Override
	public List<ResponsePayload> getAllUserEmails() throws DataAccessException {
		String query = "SELECT USERNAME, EMAIL FROM USER_24NAG2088";
		try {

			List<ResponsePayload> userEmailList = jdbcTemplate.query(query, responseBeanPropertyRowMapper);
			return userEmailList;
			
		}catch(DataAccessException e) {
			throw e;
		}
	}

}

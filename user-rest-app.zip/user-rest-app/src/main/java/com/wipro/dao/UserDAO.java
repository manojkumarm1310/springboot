package com.wipro.dao;


import java.util.List;

import org.springframework.dao.DataAccessException;

import com.wipro.model.User;
import com.wipro.payload.RequestPayload;
import com.wipro.payload.ResponsePayload;

public interface UserDAO {
	public abstract User getUserById(Integer id) throws DataAccessException;
	public abstract List<User> getAllUsers() throws DataAccessException;
	public abstract String addUser(User user) throws DataAccessException;
//	public abstract User updateUser(User user) throws DataAccessException;
	public abstract User updateUser(RequestPayload requestPayload) throws DataAccessException;
	public abstract String deleteUser(Integer id) throws DataAccessException;
	
	public abstract List<ResponsePayload> getAllUserEmails() throws DataAccessException;
	
	
}

package com.wipro.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.wipro.model.User;
import com.wipro.payload.ResponsePayload;

@Repository
public interface UserRepository extends JpaRepository<User, Integer>{
	
	
	@Query("select new com.wipro.payload.ResponsePayload(u.username,u.email) from User u")
	List<ResponsePayload> getUserNamesAndEmails();
}

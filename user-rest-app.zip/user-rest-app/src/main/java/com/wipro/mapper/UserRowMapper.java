package com.wipro.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.wipro.model.User;

@Component
public class UserRowMapper implements RowMapper<User> {

	@Override
	public User mapRow(ResultSet rs, int rowNum) throws SQLException {
		User user = new User();
		user.setId(rs.getInt("ID"));
		user.setUsername(rs.getString("USERNAME"));
		user.setPassword(rs.getString("PASSWORD"));
		user.setBirthdate(rs.getDate("BIRTHDATE").toLocalDate());
		user.setAddress(rs.getString("ADDRESS"));
		user.setEmail(rs.getString("EMAIL"));
		user.setMobile(rs.getLong("MOBILE"));
		return user;
	}

}

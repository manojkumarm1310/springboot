package com.wipro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;

import com.wipro.model.User;
import com.wipro.payload.ResponsePayload;
/*
 * Spring JDBC
 * Spring JPA
 * Spring Data JPA
 * 
 * 
 */
@SpringBootApplication
public class UserRestAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserRestAppApplication.class, args);
	}
	
	@Bean
	public BeanPropertyRowMapper<User> userBeanPropertyRowMapper(){
		return new BeanPropertyRowMapper<User>(User.class);
	}
	
	@Bean
	public BeanPropertyRowMapper<ResponsePayload> responseBeanPropertyRowMapper(){
		return new BeanPropertyRowMapper<ResponsePayload>(ResponsePayload.class);
	}

}

package com.wipro.service;

import java.util.List;

import com.wipro.exception.UserException;
import com.wipro.model.User;
import com.wipro.payload.RequestPayload;
import com.wipro.payload.ResponsePayload;

public interface UserService {
	public abstract User getUserById(Integer id) throws UserException;
	public abstract List<User> getAllUsers() throws UserException;
	public abstract String addUser(User user) throws UserException;
//	public abstract User updateUser(User user) throws UserException;
	public abstract User updateUser(RequestPayload requestPayload) throws UserException;
	public abstract String deleteUser(Integer id) throws UserException;
	
	public abstract List<ResponsePayload> getAllUserEmails() throws UserException;
}

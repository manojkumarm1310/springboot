package com.wipro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.dao.UserDaoJpaImpl;
import com.wipro.exception.UserException;
import com.wipro.model.User;
import com.wipro.payload.RequestPayload;
import com.wipro.payload.ResponsePayload;

@Service
@Transactional
public class UserServiceImpl implements UserService {
//	@Autowired
//	private UserDAO userDAO;
	
	@Autowired
	private UserDaoJpaImpl userDAO;

	@Override
	public User getUserById(Integer id) throws UserException {
		try {
			User user = userDAO.getUserById(id);
			//further processing of user object
			return user;
		}catch(DataAccessException e) {
			throw new UserException(e.getMessage(),e);
		}
	}

	@Override
	public List<User> getAllUsers() throws UserException {
		try {
			List<User> userList = userDAO.getAllUsers();
			return userList;
		}catch(DataAccessException e) {
			throw new UserException(e.getMessage(),e);
		}

	}

	
	@Override
	public String addUser(User user) throws UserException {
		try {
			// To DO: Validate the User object before passing to the method
			return userDAO.addUser(user);

		}catch(DataAccessException e) {
			throw new UserException(e.getMessage(),e);
		}
	}


//	@Override
//	public User updateUSer(User user) throws UserException {
//		try {
//			// To DO: Validate the User object before passing to the method
//			return userDAO.updateUSer(user);
//
//		}catch(DataAccessException e) {
//			throw new UserException(e.getMessage(),e);
//		}
//	}
	
	@Override
	public User updateUser(RequestPayload requestPayload) throws UserException {
		try {
			// To DO: Validate the User object before passing to the method
			return userDAO.updateUser(requestPayload);

		}catch(DataAccessException e) {
			throw new UserException(e.getMessage(),e);
		}
	}

	@Override
	public String deleteUser(Integer id) throws UserException {
		try {
			// To DO: Throw exception if user tries to delete ADMIN

			if(this.getUserById(id).getUsername().equals("ADMIN")) {
				throw new Exception("Cannot delete ADMIN ");
			}
			return userDAO.deleteUser(id);

		}catch(DataAccessException e) {
			throw new UserException(e.getMessage(),e);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return "Cannot delete an ADMIN";
	}

	@Override
	public List<ResponsePayload> getAllUserEmails() throws UserException {
		try {
			List<ResponsePayload> userEmailList = userDAO.getAllUserEmails();
			return userEmailList;
		}catch(DataAccessException e) {
			throw new UserException(e.getMessage(),e);
		}
	}

}

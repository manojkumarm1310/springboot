package com.wipro.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.wipro.dao.UserRepository;
import com.wipro.exception.UserException;
import com.wipro.model.User;
import com.wipro.payload.RequestPayload;
import com.wipro.payload.ResponsePayload;

@Service
public class UserServiceSpringData implements UserService {
	@Autowired
	private UserRepository userRepository;

	@Override
	public User getUserById(Integer id) throws UserException {
		try {
			Optional<User> optional = userRepository.findById(id);
			if(optional.isEmpty()) {
				throw new DataRetrievalFailureException("Invalid userID");
			}

			return optional.get();
		}catch(DataAccessException e) {
			throw e;
		}
	}

	@Override
	public List<User> getAllUsers() throws UserException {
		try {
			List<User> userList = userRepository.findAll();
			if(userList.isEmpty()) {
				throw new DataRetrievalFailureException("Table is empty");
			}
			return userList;
		}catch(DataAccessException e) {
			throw e;
		}
	}

	@Override
	public String addUser(User user) throws UserException {
		try {
			user.setId(null);
			User newUser = userRepository.save(user);
			return newUser.toString();
		}catch(DataAccessException e) {
			throw e;
		}
	}

	@Override
	public User updateUser(RequestPayload requestPayload) throws UserException {
		try {
			User user = this.getUserById(requestPayload.getId());
			user.setPassword(requestPayload.getPassword());
			user.setAddress(requestPayload.getAddress());
			user.setEmail(requestPayload.getEmail());
			user.setMobile(requestPayload.getMobile());
			//update and return
			return userRepository.save(user);
		}catch(DataAccessException e) {
			throw e;
		}
	}

	@Override
	public String deleteUser(Integer id) throws UserException {
		try {
			userRepository.deleteById(id);
			return "User:"+id+" deleted";
		}catch(DataAccessException e) {
			throw e;
		}
	}

	@Override
	public List<ResponsePayload> getAllUserEmails() throws UserException {
		try {
			List<ResponsePayload> respList = userRepository.getUserNamesAndEmails();
			return respList;
		}catch(DataAccessException e) {
			throw e;
		}
	}
	
//	public List<User> getUsersByPagination(int pageNo, int pageSize) {
//
//		try {
//			 Pageable pageRequest = PageRequest.of(pageNo, pageSize);
//		        //pass it to repos
//		       Page<User> pagingUser = userRepository.findAll(pageRequest);
//		       
//			if(!pagingUser.hasContent()) {
//				throw new DataRetrievalFailureException("No data found");
//			}
//
//			return pagingUser.getContent();
//		}catch(DataAccessException e) {
//			throw e;
//		}
//    }
	
	public List<User> getUsersByPagination(int pageNo, int pageSize) {
		try{
			//create pagerequest object
//			PageRequest pageRequest = PageRequest.of(pageNo, pageSize, Sort.by("username"));
			Pageable pageable = PageRequest.of(pageNo, pageSize, Sort.by("username"));
			//pass it to repos
			Page<User> pagingUser = userRepository.findAll(pageable);
			if(!pagingUser.hasContent())  { 
						throw new DataRetrievalFailureException("Data not found");
			}
			return pagingUser.getContent();
		}catch(DataAccessException e){
			throw e;
		}
	}
	
	public List<User> getSortedUsers(String name){
		try{
			Sort sort = Sort.by(name);
			List<User> userList = userRepository.findAll(sort);
			return userList;
			
		}catch(DataAccessException e){
			throw e;
		}
	}


	

}

package com.wipro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//24NAG2088_06_Manojkumar_m
//Milestone_2

@SpringBootApplication
public class SpringbootJpaRestBlogAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootJpaRestBlogAppApplication.class, args);
	}

}

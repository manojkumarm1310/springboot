package com.wipro.entity;

public enum MetricType {
    HEART_RATE,
    BLOOD_PRESSURE,
    ACTIVITY_LEVEL
}